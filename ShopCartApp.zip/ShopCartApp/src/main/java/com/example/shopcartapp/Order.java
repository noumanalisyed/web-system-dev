package com.example.shopcartapp;

import java.util.ArrayList;
import java.util.List;

public class Order {

    private String userName;
    private List<Product> productsOrdered;

    public Order(String userName) {
        this.userName = userName;
        this.productsOrdered = new ArrayList<>();
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public List<Product> getProductsOrdered() {
        return productsOrdered;
    }

    public void setProductsOrdered(List<Product> productsOrdered) {
        this.productsOrdered = productsOrdered;
    }

    public void addProducts(String products, int quantity)
    {
        Product productOrdered = new Product(products, quantity);
        productsOrdered.add(productOrdered);
    }
    public double OrderTotal()
    {
        double total = 0.0;
        for (Product productOrdered : productsOrdered) {
            total += productOrdered.getPrice() * productOrdered.getQuantity();
        }
        return total;
    }

    public Object getPrice() {
        return getPrice();
    }

}
