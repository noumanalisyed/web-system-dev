package org.example;

public interface Coach {
    public String getDailyWorkout();
    public String getDailyFortune();
    public String getInformation();
}
