package org.example;

public class CricketCoach implements Coach{

    @Override
    public String getDailyWorkout(){
        return "Do 1 hour Bowling practise";
    }
    @Override
    public String getDailyFortune(){
        return "Today is your lucky day";
    }
    @Override
    public String getInformation(){
        return "Cricket -- very popular sports in ASIA, ENGLAND and Australia";
    }
}
